cd ~/dlllciasrouter
zentyal-package
sudo dpkg -i debs-ppa/zentyal-dlllciasrouter_3.0_all.deb
